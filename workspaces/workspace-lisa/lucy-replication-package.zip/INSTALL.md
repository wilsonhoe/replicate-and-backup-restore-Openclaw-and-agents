# Lucy Replication Package

Complete OpenClaw agent setup for Mac Studio.

## Prerequisites
- macOS Sonoma or later
- Homebrew installed
- Admin access

## Stage 1: System Setup

```bash
# 1. Install dependencies
brew install node@22 python@3.12 git ffmpeg

# 2. Install OpenClaw
npm install -g openclaw

# 3. Verify installation
openclaw doctor

# 4. Create workspace
mkdir -p ~/.openclaw/workspace-lucy
```

## Stage 2: Copy Package Contents

```bash
# Copy all files from this package
cp -r agent-config/* ~/.openclaw/agents/lucy/agent/
cp -r scripts/* ~/.openclaw/workspace-lucy/scripts/
cp -r skills/* ~/.openclaw/workspace-lucy/skills/
cp -r learnings/* ~/.openclaw/workspace-lucy/.learnings/
cp templates/* ~/.openclaw/workspace-lucy/
```

## Stage 3: Configure Secrets

Edit files in `secrets/` folder with your actual tokens:
- `telegram-bot-token` — Get from @BotFather
- `discord-bot-token` — Create Discord app, get token
- `notion-api-key` — If using Notion integration
- `github-pat` — If using GitHub skills

## Stage 4: Update OpenClaw Config

Add to `~/.openclaw/openclaw.json`:

```json
{
  "agents": {
    "list": [
      {
        "id": "lucy",
        "model": "ollama/glm-5.1:cloud",
        "workspace": "/Users/YOUR_USERNAME/.openclaw/workspace-lucy",
        "agentDir": "/Users/YOUR_USERNAME/.openclaw/agents/lucy/agent"
      }
    ]
  },
  "channels": {
    "telegram": {
      "accounts": {
        "lucy": {
          "tokenFile": "/Users/YOUR_USERNAME/.openclaw/secrets/telegram-bot-token-lucy"
        }
      }
    }
  },
  "bindings": [
    {
      "agentId": "lucy",
      "match": {
        "accountId": "lucy",
        "channel": "telegram"
      }
    }
  ]
}
```

## Stage 5: Install Cron Jobs

```bash
# Import all cron jobs
openclaw cron add --file cron/lucy-morning-checkin.json
openclaw cron add --file cron/lucy-bridge-monitor.json
# ... add remaining cron jobs
```

## Stage 6: Test

```bash
# Test memory systems
python3 ~/.openclaw/workspace-lucy/scripts/memory_nudge.py

# Test FTS5 search
python3 ~/.openclaw/workspace-lucy/scripts/fts5_search.py search "test"

# Verify cron jobs
openclaw cron list
```

## Post-Install

1. Customize `SOUL.md` for Lucy's specific role
2. Set up bridge communication with Lisa if needed
3. Test Discord/Telegram integration
4. Start autonomous operation

## Support

See `SETUP-CHECKLIST.md` for detailed verification steps.
