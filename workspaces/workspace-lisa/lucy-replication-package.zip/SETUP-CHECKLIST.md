# SETUP-CHECKLIST.md

## Pre-Flight Checklist for Lucy on Mac Studio

### Stage 1: System Setup
- [ ] macOS Sonoma or later
- [ ] Homebrew installed
- [ ] Node.js v22+ (`brew install node@22`)
- [ ] Python 3.12+ (`brew install python@3.12`)
- [ ] Git installed
- [ ] Chrome/Chromium installed
- [ ] OpenClaw installed (`npm install -g openclaw`)
- [ ] `openclaw doctor` passes all checks

### Stage 2: Agent Identity
- [ ] `SOUL.md` customized for Lucy's role
- [ ] `IDENTITY.md` created
- [ ] `USER.md` copied from Lisa (Wilson's profile)
- [ ] `AGENTS.md` adapted
- [ ] `TOOLS.md` with Mac Studio specifics
- [ ] `MEMORY.md` initialized

### Stage 3: Secrets Configuration
- [ ] Telegram bot token created (@BotFather)
- [ ] Discord bot token created (if using)
- [ ] Notion API key (if needed)
- [ ] GitHub PAT (if needed)
- [ ] All tokens saved to `~/.openclaw/secrets/`

### Stage 4: OpenClaw Config
- [ ] Lucy added to `agents.list` in `~/.openclaw/openclaw.json`
- [ ] Telegram channel binding configured
- [ ] Discord channel binding configured (if using)
- [ ] Model set to `ollama/glm-5.1:cloud`

### Stage 5: Test Systems
- [ ] `python3 scripts/memory_nudge.py` runs without error
- [ ] `python3 scripts/fts5_search.py search test` returns results
- [ ] `python3 scripts/skill_factory.py` can create skills
- [ ] Memory files are being written to `memory/`

### Stage 6: Cron Jobs
- [ ] Morning checkin cron added
- [ ] Bridge monitor cron added
- [ ] All other crons configured
- [ ] `openclaw cron list` shows all jobs

### Stage 7: Communication
- [ ] Bridge directory accessible to Lisa
- [ ] Test message sent from Lucy to Lisa
- [ ] Test message received from Lisa

### Stage 8: Production Ready
- [ ] Autonomous mode enabled
- [ ] Proactive agent hook configured
- [ ] Memory wiki bridge active
- [ ] Lucy is executing tasks independently

## Post-Setup Verification

Run these commands:
```bash
# Verify installation
openclaw doctor

# Test memory systems
python3 ~/.openclaw/workspace-lucy/scripts/memory_nudge.py

# Test FTS5 search
python3 ~/.openclaw/workspace-lucy/scripts/fts5_search.py search "test"

# Check cron jobs
openclaw cron list

# Verify agent binding
openclaw sessions list
```

## Troubleshooting

**Script fails with "No module named X":**
- Install missing packages: `pip3 install X`

**Ollama connection refused:**
- Start Ollama: `ollama serve`
- Or set different baseUrl in config

**Chrome not found:**
- Update path in TOOLS.md: `/Applications/Google Chrome.app/Contents/MacOS/Google Chrome`

**Permission denied on scripts:**
- `chmod +x ~/.openclaw/workspace-lucy/scripts/*.py`
